This CopyRightChecker checks copyright of source files from github .

first it  clones existing repository and downloads your repo into the system .


then walks each directory of repo and checks for source files and appends the appropriate copy right to it.

finally it pushes back code to a branch repository .
